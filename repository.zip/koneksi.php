<?php
// isi nama host, username mysql, dan password mysql anda
$host = mysqli_connect("localhost", "root", "");

// isikan dengan nama database yang akan di hubungkan
$db = mysqli_select_db($host, "repository");
